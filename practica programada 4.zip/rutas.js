const express = require('express');
const { addComment, getComments, updateComment, deleteComment } = require('../controllers/comments');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// Crear un comentario
router.post('/', authenticate, addComment);

// Obtener comentarios de una tarea
router.get('/:taskId', authenticate, getComments);

// Actualizar un comentario
router.put('/:commentId', authenticate, updateComment);

// Eliminar un comentario
router.delete('/:commentId', authenticate, deleteComment);

module.exports = router;
