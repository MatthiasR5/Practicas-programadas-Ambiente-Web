const Comment = require('../models/Comment');

// Crear un comentario
const addComment = async (req, res) => {
    try {
        const { taskId, content, author } = req.body;
        const comment = new Comment({ taskId, content, author });
        await comment.save();
        res.status(201).json({ message: 'Comentario creado', comment });
    } catch (error) {
        res.status(500).json({ message: 'Error al crear el comentario', error });
    }
};

// Obtener comentarios por tarea
const getComments = async (req, res) => {
    try {
        const { taskId } = req.params;
        const comments = await Comment.find({ taskId });
        res.status(200).json(comments);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener los comentarios', error });
    }
};

// Actualizar un comentario
const updateComment = async (req, res) => {
    try {
        const { commentId } = req.params;
        const { content } = req.body;
        const updatedComment = await Comment.findByIdAndUpdate(commentId, { content }, { new: true });
        res.status(200).json({ message: 'Comentario actualizado', updatedComment });
    } catch (error) {
        res.status(500).json({ message: 'Error al actualizar el comentario', error });
    }
};

// Eliminar un comentario
const deleteComment = async (req, res) => {
    try {
        const { commentId } = req.params;
        await Comment.findByIdAndDelete(commentId);
        res.status(200).json({ message: 'Comentario eliminado' });
    } catch (error) {
        res.status(500).json({ message: 'Error al eliminar el comentario', error });
    }
};

module.exports = { addComment, getComments, updateComment, deleteComment };
